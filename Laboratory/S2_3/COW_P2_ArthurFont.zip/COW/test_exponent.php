<?php
    $base = $_GET['base'];
    $exp = $_GET['exp'];
    $result = pow($base, $exp);
    echo "$base ^ $exp = $result";
?>
 
